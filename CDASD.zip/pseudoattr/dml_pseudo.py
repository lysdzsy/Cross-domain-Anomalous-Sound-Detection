# import os
# os.environ["OMP_NUM_THREADS"] = "1"
# import pandas as pd
# import numpy as np
# import json
# from pathlib import Path
# from sklearn.preprocessing import StandardScaler
# from tqdm import tqdm
# from sklearn.metrics.pairwise import cosine_similarity
# import networkx as nx
# import community as community_louvain  # 需 pip install python-louvain
#
# def load_and_merge_embeddings(beats_path, eats_path):
#     df_beats = pd.read_csv(beats_path)
#     df_eats = pd.read_csv(eats_path)
#     assert set(df_beats['path']) == set(df_eats['path']), "Mismatch in paths"
#     df_beats = df_beats.sort_values('path').reset_index(drop=True)
#     df_eats = df_eats.sort_values('path').reset_index(drop=True)
#     feats_beats = df_beats[[col for col in df_beats.columns if col.startswith('e')]]
#     feats_eats = df_eats[[col for col in df_eats.columns if col.startswith('e')]]
#     combined_feats = pd.concat([feats_beats, feats_eats], axis=1)
#
#     # 添加完整路径前缀
#     root_prefix = "E:/third_year/fourth_paper_refer_code/unlabeledasd-main/data_dir//dcase2024/all/raw/"
#     paths = [str(Path(root_prefix) / p).replace("\\", "/") for p in df_beats['path'].tolist()]
#
#     return combined_feats.to_numpy(), paths
# def graph_cluster_features(X, k_neighbors=10):
#     sim = cosine_similarity(X)
#     np.fill_diagonal(sim, 0)
#     G = nx.Graph()
#     for i in range(len(X)):
#         topk = np.argsort(sim[i])[-k_neighbors:]
#         for j in topk:
#             G.add_edge(i, j, weight=sim[i, j])
#     partition = community_louvain.best_partition(G, weight='weight')
#     labels = np.array([partition[i] for i in range(len(X))])
#     return labels
#
# def main():
#     machines = [
#         "ToyTrain", "gearbox", "slider",
#         "AirCompressor", "BrushlessMotor", "HoveringDrone", "ToothBrush"
#     ]
#     beats_root = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/embed/dcase2024/beats")
#     eats_root = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/embed/dcase2024/eat")
#     output_dir = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/label/dcase2024/dml_all")
#     output_dir.mkdir(parents=True, exist_ok=True)
#
#     all_strlabel_dict = {}
#
#     for machine in tqdm(machines):
#         print(f"\n🚀 Processing: {machine}")
#         beats_path = beats_root / f"BEATs_iter3_plus_AS2M_{machine}.csv"
#         eats_path = eats_root / f"EAT-base-epoch30_{machine}.csv"
#         X_all, paths_all = load_and_merge_embeddings(beats_path, eats_path)
#         X_all = StandardScaler().fit_transform(X_all)
#
#         # 拆分 source 和 target 域
#         source_indices = [i for i, p in enumerate(paths_all) if "source" in p]
#         target_indices = [i for i, p in enumerate(paths_all) if "target" in p]
#
#         for domain, indices in zip(["source", "target"], [source_indices, target_indices]):
#             if len(indices) < 10:
#                 print(f"    ⚠ Too few samples in {domain}, skipping...")
#                 continue
#
#             X = X_all[indices]
#             paths = [paths_all[i] for i in indices]
#
#             pseudo_labels = graph_cluster_features(X, k_neighbors=10)
#             # 统计当前 machine + domain 的聚类数
#             num_clusters = len(set(pseudo_labels))
#             print(f"    ✅ {machine}-{domain}: {num_clusters} clusters")
#             for p, label in zip(paths, pseudo_labels):
#                 all_strlabel_dict[p] = f"{machine}-{domain}-{label}"
#
#     # 保存 strlabel.json
#     with open(output_dir / "strlabel.json", 'w') as f:
#         json.dump(all_strlabel_dict, f, indent=2)
#
#     print("\n✅ All done. strlabel.json saved to:", output_dir)
#
#
# if __name__ == '__main__':
#     main()



#################两阶段Louvain和Leiden
import os
os.environ["OMP_NUM_THREADS"] = "1"
import json
import numpy as np
import pandas as pd
from pathlib import Path
from tqdm import tqdm
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import KMeans
import networkx as nx
import community as community_louvain  # from python-louvain
import igraph as ig
import leidenalg
# # 加载并合并 BEATs 与 EAT 特征
# def load_and_merge_embeddings(beats_path, eats_path):
#     df_beats = pd.read_csv(beats_path)
#     df_eats = pd.read_csv(eats_path)
#     assert set(df_beats['path']) == set(df_eats['path']), "Mismatch in paths"
#     df_beats = df_beats.sort_values('path').reset_index(drop=True)
#     df_eats = df_eats.sort_values('path').reset_index(drop=True)
#
#     feats_beats = df_beats[[col for col in df_beats.columns if col.startswith('e')]]
#     feats_eats = df_eats[[col for col in df_eats.columns if col.startswith('e')]]
#     combined_feats = pd.concat([feats_beats, feats_eats], axis=1)
#
#     root_prefix = "E:/third_year/fourth_paper_refer_code/unlabeledasd-main/data_dir//dcase2024/all/raw/"
#     paths = [str(Path(root_prefix) / p).replace("\\", "/") for p in df_beats['path'].tolist()]
#     return combined_feats.to_numpy(), paths
#
# # 阶段一：Louvain 聚类获取初始标签
# def louvain_cluster(X, k_neighbors=10):
#     sim = cosine_similarity(X)
#     np.fill_diagonal(sim, 0)
#     G = nx.Graph()
#     for i in range(len(X)):
#         topk = np.argsort(sim[i])[-k_neighbors:]
#         for j in topk:
#             G.add_edge(i, j, weight=sim[i, j])
#     partition = community_louvain.best_partition(G, weight='weight')
#     labels = np.array([partition[i] for i in range(len(X))])
#     return labels
#
# def leiden_cluster(X, k_neighbors=10):
#     sim = cosine_similarity(X)
#     np.fill_diagonal(sim, 0)
#
#     edges = []
#     weights = []
#
#     for i in range(len(X)):
#         topk = np.argsort(sim[i])[-k_neighbors:]
#         for j in topk:
#             edges.append((i, j))
#             weights.append(sim[i, j])
#
#     # 构建 igraph 图
#     g = ig.Graph()
#     g.add_vertices(len(X))
#     g.add_edges(edges)
#     g.es['weight'] = weights
#
#     # 执行 Leiden 社区发现
#     partition = leidenalg.find_partition(g, leidenalg.ModularityVertexPartition, weights=g.es['weight'])
#
#     labels = np.zeros(len(X), dtype=int)
#     for cluster_id, nodes in enumerate(partition):
#         for node in nodes:
#             labels[node] = cluster_id
#     return labels
#
# # 阶段二：基于每类均值+std构建新特征向量，再做 KMeans refinement
# def refine_cluster_by_statistics(X, init_labels):
#     unique_labels = sorted(set(init_labels))
#     stats = []
#     for label in unique_labels:
#         cluster_feats = X[init_labels == label]
#         mean_vec = cluster_feats.mean(axis=0)
#         std_vec = cluster_feats.std(axis=0)
#         stats.append(np.concatenate([mean_vec, std_vec]))
#     stats = np.stack(stats)
#
#     # 自动寻找最优聚类数
#     best_k = 2
#     best_score = -1
#     best_labels = None
#     for k in range(2, min(16, len(stats)) + 1):
#         km = KMeans(n_clusters=k, random_state=0)
#         cluster_labels = km.fit_predict(stats)
#         if len(set(cluster_labels)) > 1:
#             # Silhouette 太少样本不稳，直接选最好聚类区分度
#             if len(set(cluster_labels)) > best_score:
#                 best_score = len(set(cluster_labels))
#                 best_k = k
#                 best_labels = cluster_labels
#
#     label_mapping = {old: new for old, new in zip(unique_labels, best_labels)}
#     refined_labels = np.array([label_mapping[lab] for lab in init_labels])
#     return refined_labels, len(set(refined_labels))
#
# ##########迭代
# def iterative_refinement(X, init_labels, max_iter=3):
#     prev_labels = init_labels
#     for i in range(max_iter):
#         new_labels, _ = refine_cluster_by_statistics(X, prev_labels)
#         # 若标签不再变化则停止
#         if np.array_equal(new_labels, prev_labels):
#             print(f"    🔁 Refinement converged at iteration {i+1}")
#             break
#         prev_labels = new_labels
#     return prev_labels
#
# # 主流程
# def main():
#     machines = [
#         "ToyTrain", "gearbox", "slider",
#         "AirCompressor", "BrushlessMotor", "HoveringDrone", "ToothBrush"
#     ]
#     beats_root = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/embed/dcase2024/beats")
#     eats_root = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/embed/dcase2024/eat")
#     output_dir = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/label/dcase2024/graph_leiden_diedai/graph_leiden_diedai")
#     output_dir.mkdir(parents=True, exist_ok=True)
#
#     all_strlabel_dict = {}
#
#     for machine in tqdm(machines):
#         print(f"\n🚀 Processing: {machine}")
#         beats_path = beats_root / f"BEATs_iter3_plus_AS2M_{machine}.csv"
#         eats_path = eats_root / f"EAT-base-epoch30_{machine}.csv"
#         X_all, paths_all = load_and_merge_embeddings(beats_path, eats_path)
#         X_all = StandardScaler().fit_transform(X_all)
#
#         source_indices = [i for i, p in enumerate(paths_all) if "source" in p]
#         target_indices = [i for i, p in enumerate(paths_all) if "target" in p]
#
#         for domain, indices in zip(["source", "target"], [source_indices, target_indices]):
#             if len(indices) < 10:
#                 print(f"    ⚠ Too few samples in {domain}, skipping...")
#                 continue
#
#             X = X_all[indices]
#             paths = [paths_all[i] for i in indices]
#
#             # Stage 1: Louvain
#             #stage1_labels = louvain_cluster(X, k_neighbors=10)
#             # Stage 1: Leiden
#             stage1_labels = leiden_cluster(X, k_neighbors=10)
#
#             # Stage 2: Refinement
#             #refined_labels, n_clusters = refine_cluster_by_statistics(X, stage1_labels)
#
#             ########迭代
#             refined_labels = iterative_refinement(X, stage1_labels, max_iter=3)
#             n_clusters = len(set(refined_labels))
#
#             print(f"    ✅ {machine}-{domain}: {n_clusters} refined clusters")
#
#             for p, label in zip(paths, refined_labels):
#                 all_strlabel_dict[p] = f"{machine}-{domain}-{label}"
#
#     with open(output_dir / "strlabel.json", 'w') as f:
#         json.dump(all_strlabel_dict, f, indent=2)
#     print("\n✅ All done. strlabel.json saved to:", output_dir)
#
# if __name__ == '__main__':
#     main()





##########仅使用 EAT 特征进行聚类并生成伪标签
# 仅加载 EAT 特征
def load_eat_embeddings(eats_path):
    df_eats = pd.read_csv(eats_path)
    feats_eats = df_eats[[col for col in df_eats.columns if col.startswith('e')]]
    root_prefix = "E:/third_year/fourth_paper_refer_code/unlabeledasd-main/data_dir//dcase2024/all/raw/"
    paths = [str(Path(root_prefix) / p).replace("\\", "/") for p in df_eats['path'].tolist()]
    return feats_eats.to_numpy(), paths

# Leiden 聚类
def leiden_cluster(X, k_neighbors=10):
    sim = cosine_similarity(X)
    np.fill_diagonal(sim, 0)

    edges = []
    weights = []

    for i in range(len(X)):
        topk = np.argsort(sim[i])[-k_neighbors:]
        for j in topk:
            edges.append((i, j))
            weights.append(sim[i, j])

    g = ig.Graph()
    g.add_vertices(len(X))
    g.add_edges(edges)
    g.es['weight'] = weights

    partition = leidenalg.find_partition(g, leidenalg.ModularityVertexPartition, weights=g.es['weight'])

    labels = np.zeros(len(X), dtype=int)
    for cluster_id, nodes in enumerate(partition):
        for node in nodes:
            labels[node] = cluster_id
    return labels

# 基于每类统计量的聚类细化
def refine_cluster_by_statistics(X, init_labels):
    unique_labels = sorted(set(init_labels))
    stats = []
    for label in unique_labels:
        cluster_feats = X[init_labels == label]
        mean_vec = cluster_feats.mean(axis=0)
        std_vec = cluster_feats.std(axis=0)
        stats.append(np.concatenate([mean_vec, std_vec]))
    stats = np.stack(stats)

    best_k = 2
    best_score = -1
    best_labels = None
    for k in range(2, min(16, len(stats)) + 1):
        km = KMeans(n_clusters=k, random_state=0)
        cluster_labels = km.fit_predict(stats)
        if len(set(cluster_labels)) > best_score:
            best_score = len(set(cluster_labels))
            best_k = k
            best_labels = cluster_labels

    label_mapping = {old: new for old, new in zip(unique_labels, best_labels)}
    refined_labels = np.array([label_mapping[lab] for lab in init_labels])
    return refined_labels, len(set(refined_labels))

# 迭代聚类细化
def iterative_refinement(X, init_labels, max_iter=3):
    prev_labels = init_labels
    for i in range(max_iter):
        new_labels, _ = refine_cluster_by_statistics(X, prev_labels)
        if np.array_equal(new_labels, prev_labels):
            print(f"    🔁 Refinement converged at iteration {i+1}")
            break
        prev_labels = new_labels
    return prev_labels

# 主流程（仅 EAT）
def main():
    machines = [
        "ToyTrain", "gearbox", "slider",
        "AirCompressor", "BrushlessMotor", "HoveringDrone", "ToothBrush"
    ]
    eats_root = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/embed/dcase2024/eat")
    output_dir = Path("E:/third_year/fourth_paper_refer_code/unlabeledasd-main/pseudoattr/label/dcase2024/graph_leiden_diedai_eat/graph_leiden_diedai_eat")
    output_dir.mkdir(parents=True, exist_ok=True)

    all_strlabel_dict = {}

    for machine in tqdm(machines):
        print(f"\n🚀 Processing: {machine}")
        eats_path = eats_root / f"EAT-base-epoch30_{machine}.csv"
        X_all, paths_all = load_eat_embeddings(eats_path)
        X_all = StandardScaler().fit_transform(X_all)

        source_indices = [i for i, p in enumerate(paths_all) if "source" in p]
        target_indices = [i for i, p in enumerate(paths_all) if "target" in p]

        for domain, indices in zip(["source", "target"], [source_indices, target_indices]):
            if len(indices) < 10:
                print(f"    ⚠ Too few samples in {domain}, skipping...")
                continue

            X = X_all[indices]
            paths = [paths_all[i] for i in indices]

            stage1_labels = leiden_cluster(X, k_neighbors=10)
            refined_labels = iterative_refinement(X, stage1_labels, max_iter=3)
            n_clusters = len(set(refined_labels))

            print(f"    ✅ {machine}-{domain}: {n_clusters} refined clusters")

            for p, label in zip(paths, refined_labels):
                all_strlabel_dict[p] = f"{machine}-{domain}-{label}"

    with open(output_dir / "strlabel.json", 'w') as f:
        json.dump(all_strlabel_dict, f, indent=2)
    print("\n✅ All done. strlabel.json saved to:", output_dir)

if __name__ == '__main__':
    main()
