from pathlib import Path
import os
os.environ["OMP_NUM_THREADS"] = "4"
os.environ["MKL_NUM_THREADS"] = "4"

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm


def extract(model, loader, device):
    emb_list = []
    path_list = []

    for wave, path in tqdm(loader):
        with torch.no_grad():
            embed = model(wave)["embedding"]  # 不提前 .to(device)，内部自己处理
        if isinstance(embed, torch.Tensor):
            embed = embed.cpu().numpy()
        emb_list.append(embed)
        path_list.extend(path)  # 注意这里 extend 而不是 append

    emb_array = np.concatenate(emb_list, axis=0)  # shape: (N, D)

    ecols = [f"e{i}" for i in range(model.embedding_size)]
    df_emb = pd.DataFrame(emb_array, columns=ecols)
    df_emb["path"] = path_list

    # 最后将路径列放前面（可选）
    df = df_emb[["path"] + ecols]

    return df




# def get_train_dom_csv(path, dom):
#     df = pd.read_csv(path)
#     train_idx = np.array([p.split("/")[-2] == "train" for p in df.path.values])
#     if dom is None:
#         return df.loc[train_idx]
#     else:
#         dom_idx = np.array(
#             [p.split("/")[-1].split("_")[2] == dom for p in df.path.values]
#         )
#         return df.loc[train_idx & dom_idx]
def get_train_dom_csv(path, dom):
    df = pd.read_csv(path)

    # ✅ 修复Windows下反斜杠路径的问题
    df["path"] = df["path"].apply(lambda p: p.replace("\\", "/"))

    # ✅ 更鲁棒地判断是否是 train 数据
    train_idx = df["path"].apply(lambda p: "/train/" in p).values

    if dom is None:
        return df.loc[train_idx]
    else:
        # ✅ 更稳妥判断 domain，比如 "_source_" 或 "_target_"
        dom_idx = df["path"].apply(lambda p: f"_{dom}_" in p).values
        return df.loc[train_idx & dom_idx]


def extract_emb(df, keyword="e"):
    ecols = [col for col in df.keys() if col[0] == keyword and int(col[1:]) >= 0]
    return df[ecols].values


def get_org_attr_machines(data_dir, pseudo_attr_machines):
    all_machines = [p.stem for p in Path(f"{data_dir}").glob("*")]
    org_attr_machines = []
    for m in all_machines:
        if m not in pseudo_attr_machines:
            org_attr_machines += [m]
    return org_attr_machines
