# Copyright 2024 Takuya Fujimura
from models.grl_classifier import GRLClassifier
import torch.nn as nn

from typing import Dict

import torch
import torch.nn.functional as F
from hydra.utils import instantiate
from torch import Tensor
import numpy as np
from models import CutMixLayer, MixupLayer, get_perm
from models import GRLClassifier
from models import SCAdaCos
from .base_model import BasePLModel




class SubspaceLossPLModel(BasePLModel):
    def __init__(self, config):
        super().__init__(config)

    def _constructor(
        self,
        label_dict={},
        extractor_cfg={},
        loss_cfg={},
        mixup_prob=0.5,
        mixup_type="mixup",
        lam=1,
        aug_cfg_list=[],
    ) -> None:
        self.label_dict = label_dict
        self.extractor = instantiate(extractor_cfg)
        self.loss_cfg = loss_cfg
        self.embedding_size = self.extractor.embedding_size
        self.embedding_split_size = self.extractor.embedding_split_size
        self.embedding_split_num = self.extractor.embedding_split_num
        self.mixup_prob = mixup_prob
        self.mixup_type = mixup_type

        if self.mixup_type == "cutmix":
            self.mixup = CutMixLayer(mixup_prob, list(self.label_dict.keys()))
        elif self.mixup_type == "mixup":
            self.mixup = MixupLayer(mixup_prob, list(self.label_dict.keys()))
        else:
            raise NotImplementedError()

        self.main_head_dict = torch.nn.ModuleDict({})
        self.split_head_dict = torch.nn.ModuleDict({})
        for key_, dict_ in self.label_dict.items():
            main_loss_cfg = {
                **{
                    "n_classes": dict_["num"],
                    "embed_size": self.embedding_size,
                    "trainable": False,
                },
                **self.loss_cfg,
            }
            self.main_head_dict[key_] = instantiate(main_loss_cfg)
            split_loss_cfg = {
                **{
                    "n_classes": dict_["num"],
                    "embed_size": self.embedding_split_size,
                    "trainable": True,
                },
                **self.loss_cfg,
            }
            self.split_head_dict[key_] = torch.nn.ModuleList(
                [instantiate(split_loss_cfg) for _ in range(self.embedding_split_num)]
            )



        self.lam = lam

        self.augmentations = torch.nn.ModuleList([])
        for cfg in aug_cfg_list:
            self.augmentations.append(instantiate(cfg))


        ########## 添加 GRL 分类器（用于 onehot_pattr 的属性对抗）
        # if "onehot_pattr" in self.label_dict:
        #     self.grl_classifier = GRLClassifier(
        #         in_dim=self.embedding_size,
        #         hidden_dim=128,
        #         num_classes=self.label_dict["onehot_pattr"]["num"],
        #         lambda_=1.0  # 可设为超参
        #     )
        #     self.grl_loss_fn = nn.CrossEntropyLoss()
        #     self.grl_lambda = 0.1  # ✅ GRL 对抗损失权重，建议使用独立控制参数

        ###########多层GRL分类器
        # self.grl_classifiers = nn.ModuleList()
        # for i in range(self.embedding_split_num):
        #     self.grl_classifiers.append(
        #         GRLClassifier(
        #             in_dim=self.embedding_split_size,
        #             hidden_dim=128,
        #             num_classes=self.label_dict["onehot_pattr"]["num"],
        #             lambda_=1.0
        #         )
        #     )
        # self.grl_loss_fn = nn.CrossEntropyLoss()
        # self.grl_lambda = 0.01

        # 多层 GRL 分类器（SCAdaCos 版本）
        # self.grl_classifiers = nn.ModuleList()
        # for i in range(self.embedding_split_num):
        #     self.grl_classifiers.append(
        #         SCAdaCos(
        #             embed_size=self.embedding_split_size,
        #             n_classes=self.label_dict["onehot_pattr"]["num"],
        #             trainable=True,
        #             dynamic=True,
        #         )
        #     )
        # self.grl_lambda = 0.01  # 可调

        # 多层 GRL 分类器
        # self.grl_strength = 1  # 控制梯度反转强度（反向传播时乘以 -lambda）
        # self.grl_loss_weight = 0.001  # 控制损失加权（加入总 loss）
        # self.grl_classifiers = nn.ModuleList()
        # self.grl_losses = nn.ModuleList()
        # for i in range(self.embedding_split_num):
        #     self.grl_classifiers.append(
        #         GRLClassifier(
        #             in_dim=self.embedding_split_size,
        #             hidden_dim=128,  # 可以根据你自己模型需要改
        #             lambda_=self.grl_strength
        #         )
        #     )
        #     self.grl_losses.append(
        #         SCAdaCos(
        #             embed_size=128,
        #             n_classes=self.label_dict["onehot_pattr"]["num"],
        #             trainable=True,
        #             dynamic=True,
        #         )
        #     )

    def forward(self, wave: Tensor) -> Dict:
        """
        Args:
            x (Tensor): wave (B, T)
        """
        embedding, _ = self.extractor(wave)
        return {"embedding": F.normalize(embedding, dim=1)}

    def training_step(self, batch, batch_idx):
        for aug_func in self.augmentations:
            batch = aug_func(batch)

        wave = batch.pop("wave")
        labels = batch  # just renamed

        wave, labels_mixup = self.mixup(wave, labels)
        embedding, z_list = self.extractor(wave)
        assert len(z_list) == self.embedding_split_num

        loss_dict = {"main": 0.0}
        for key_ in self.label_dict:
            l_main = self.main_head_dict[key_](embedding, labels_mixup[key_])
            l_other = 0.0
            for i, z in enumerate(z_list):
                loss_dict[f"{key_}_other_{i}"] = self.split_head_dict[key_][i](
                    z, labels_mixup[key_]
                )
                l_other += loss_dict[f"{key_}_other_{i}"]

            ##############修改为
            # # # === 差异增强注意力权重 ===
            # with torch.no_grad():
            #     z_stack = torch.stack(z_list, dim=1)  # [B, N, D]
            #     z_mean = z_stack.mean(dim=1, keepdim=True)  # [B, 1, D]
            #     sim = F.cosine_similarity(z_stack, z_mean, dim=-1)  # [B, N]
            #     diff_score = 1.0 - sim  # 越不相似越重要
            #     branch_weights = F.softmax(diff_score.mean(dim=0), dim=0)  # [N]
            #
            # # === 加权多分支损失 ===
            # l_other = 0.0
            # for i, z in enumerate(z_list):
            #     loss_i = self.split_head_dict[key_][i](z, labels_mixup[key_])
            #     weighted_loss = branch_weights[i] * loss_i
            #     loss_dict[f"{key_}_other_{i}"] = weighted_loss
            #     l_other += weighted_loss







            loss_dict[key_] = l_main
            loss_dict["main"] += l_main + self.lam * l_other  # 保持原有结构
        ########## 添加 GRL 分类器（用于 onehot_pattr 的属性对抗）
        # if hasattr(self, "grl_classifier"):
        #     domain_logits = self.grl_classifier(embedding)
        #     domain_loss = self.grl_loss_fn(domain_logits, labels_mixup["onehot_pattr"])
        #     loss_dict["domain_adv"] = domain_loss
        #     loss_dict["main"] += self.grl_lambda * domain_loss

        ###########多层GRL分类器
        # if hasattr(self, "grl_classifiers"):
        #     for i, (z, grl_clf) in enumerate(zip(z_list, self.grl_classifiers)):
        #         domain_logits = grl_clf(z)
        #         domain_loss = self.grl_loss_fn(domain_logits, labels_mixup["onehot_pattr"])
        #         loss_dict[f"domain_adv_{i}"] = domain_loss
        #         loss_dict["main"] += self.grl_lambda * domain_loss


        # 多层 GRL 分类器（SCAdaCos 版本）
        # if hasattr(self, "grl_classifiers"):
        #     for i, (z, grl_clf) in enumerate(zip(z_list, self.grl_classifiers)):
        #         domain_loss = grl_clf(z, labels_mixup["onehot_pattr"])  # ✅ 直接返回 loss
        #         loss_dict[f"domain_adv_{i}"] = domain_loss
        #         loss_dict["main"] += self.grl_lambda * domain_loss

        # GRL 分类器对抗训练
        # for i, (z, grl_clf, grl_loss_fn) in enumerate(zip(z_list, self.grl_classifiers, self.grl_losses)):
        #     z_reversed = grl_clf(z)  # 得到嵌入特征（经过梯度反转）
        #     domain_loss = grl_loss_fn(z_reversed, labels_mixup["onehot_pattr"])  # SCAdaCos 损失
        #     loss_dict[f"domain_adv_{i}"] = domain_loss
        #     loss_dict["main"] += self.grl_loss_weight * domain_loss




        self.log_loss(torch.tensor(len(wave)).float(), "train/batch_size", 1)
        for tag_, val_ in loss_dict.items():
            self.log_loss(val_, f"train/{tag_}", len(wave))

        return loss_dict["main"]






