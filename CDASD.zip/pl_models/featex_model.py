# Copyright 2024 Takuya Fujimura
from models.grl_classifier import GRLClassifier
from typing import Dict
import torch.nn as nn
import torch
import torch.nn.functional as F
from hydra.utils import instantiate
from torch import Tensor
import numpy as np
from models import CutMixLayer, FeatExLayer, MixupLayer

from .base_model import BasePLModel
#
# class SCAdaCos(nn.Module):
#     def __init__(
#         self,
#         embed_size,
#         n_classes=None,
#         n_subclusters=1,
#         eps=1e-7,
#         trainable=False,
#         reduction="mean",
#         dynamic=True,
#     ):
#         super().__init__()
#         self.n_classes = n_classes
#         self.n_subclusters = n_subclusters
#         self.s_init = np.sqrt(2) * np.log(n_classes * n_subclusters - 1)
#         self.eps = eps
#
#         # Weight initialization
#         self.W = nn.Parameter(
#             torch.Tensor(embed_size, n_classes * n_subclusters), requires_grad=trainable
#         )
#         nn.init.xavier_uniform_(self.W.data)
#
#         # Scale factor
#         self.s = nn.Parameter(torch.tensor(self.s_init), requires_grad=False)
#         self.reduction = reduction
#         self.loss_fn = nn.CrossEntropyLoss(reduction=self.reduction)
#
#         self.dynamic = dynamic
#
#     def forward(self, x, t):
#         t_orig = t.clone()
#         t = t.repeat(1, self.n_subclusters)
#
#         x = F.normalize(x, p=2, dim=1)
#         W = F.normalize(self.W, p=2, dim=0)
#
#         # Dot product
#         logits = torch.mm(x, W)
#         theta = torch.acos(torch.clamp(logits, -1.0 + self.eps, 1.0 - self.eps))
#
#         if self.training and self.dynamic:
#             with torch.no_grad():
#                 max_s_logits = torch.max(self.s * logits)
#                 B_avg = torch.exp(self.s * logits - max_s_logits)  # re-scaling trick
#                 B_avg = torch.mean(torch.sum(B_avg, dim=1))
#                 theta_class = torch.sum(t * theta, dim=1)
#                 theta_med = torch.median(theta_class)
#                 self.s.data = max_s_logits + torch.log(B_avg)  # re-scaling trick
#                 self.s.data /= (
#                     torch.cos(min(torch.tensor(np.pi / 4), theta_med)) + self.eps
#                 )
#
#         logits *= self.s
#         prob = F.softmax(logits, dim=1)
#         prob = prob.view(
#             -1, self.n_classes, self.n_subclusters
#         )  # (B, C, n_subclusters)
#         prob = torch.sum(prob, dim=2)  # (B, C)
#         loss = self.loss_fn(torch.log(prob), t_orig)
#         return loss


class FeatExPLModel(BasePLModel):
    def __init__(self, config):
        super().__init__(config)

    def _constructor(
        self,
        label_dict={},
        extractor_cfg={},
        loss_cfg={},
        mixup_prob=0.5,
        featex_prob=0.5,
        mixup_type="mixup",
        lam=1.0,
    ) -> None:
        self.label_dict = label_dict
        self.extractor = instantiate(extractor_cfg)
        self.loss_cfg = loss_cfg
        self.embedding_size = self.extractor.embedding_size
        self.embedding_split_size = self.extractor.embedding_split_size
        self.embedding_split_num = self.extractor.embedding_split_num
        self.featex_prob = featex_prob
        self.featex = FeatExLayer(
            featex_prob,
            list(self.label_dict.keys()),
            self.embedding_split_num,
        )
        self.lam = lam

        if mixup_type == "cutmix":
            self.mixup = CutMixLayer(
                mixup_prob,
                list(self.label_dict.keys()),
            )
        elif mixup_type == "mixup":
            self.mixup = MixupLayer(mixup_prob, list(self.label_dict.keys()))
        else:
            raise NotImplementedError()

        self.head_dict = torch.nn.ModuleDict({})
        for key_, dict_ in self.label_dict.items():
            self.head_dict[key_] = torch.nn.ModuleDict({})
            for loss_name, i in zip(
                ["mixup", "featex"], [1, (self.embedding_split_num + 1)]
            ):
                loss_cfg = {
                    **{
                        "n_classes": dict_["num"] * i,
                        "embed_size": self.embedding_size,
                        "trainable": loss_name == "featex",
                    },
                    **self.loss_cfg,
                }
                self.head_dict[key_][loss_name] = instantiate(loss_cfg)


        # ##########单层 添加 GRL 分类器（用于 onehot_pattr 的属性对抗）
        # if "onehot_pattr" in self.label_dict:
        #     self.grl_classifier = GRLClassifier(
        #         in_dim=self.embedding_size,
        #         hidden_dim=128,
        #         num_classes=self.label_dict["onehot_pattr"]["num"],
        #         lambda_=1.0  # 可设为超参
        #     )
        #     self.grl_loss_fn = nn.CrossEntropyLoss()
        #     self.grl_lambda = 0.1  # ✅ GRL 对抗损失权重，建议使用独立控制参数



        # ################多层 添加 GRL 对抗模块（SCAdaCos 为例）
        # self.grl_classifiers = nn.ModuleList()
        # for _ in range(self.embedding_split_num):
        #     self.grl_classifiers.append(
        #         SCAdaCos(
        #             embed_size=self.embedding_split_size,
        #             n_classes=self.label_dict["onehot_pattr"]["num"],
        #             trainable=True,
        #             dynamic=True,
        #         )
        #     )
        # self.grl_lambda = 0.01  # 可调超参

    def forward(self, wave: Tensor) -> Dict:
        """
        Args:
            x (Tensor): wave (B, T)
        """
        embedding, _ = self.extractor(wave)
        return {"embedding": F.normalize(embedding, dim=1)}

    def training_step(self, batch, batch_idx):
        wave = batch.pop("wave")
        labels = batch  # just renamed

        wave, labels_mixup = self.mixup(wave, labels)
        embedding, z_list = self.extractor(wave)
        embedding_featex, labels_featex = self.featex(z_list, labels_mixup)

        loss_dict = {"main": 0.0}
        for key_ in self.label_dict:
            l_mixup = self.head_dict[key_]["mixup"](embedding, labels_mixup[key_])

            if self.featex_prob > 0.0:
                l_featex = self.head_dict[key_]["featex"](
                    embedding_featex, labels_featex[key_]
                )
            else:
                l_featex = 0.0

            loss_dict[key_] = l_mixup + self.lam * l_featex
            loss_dict["main"] += loss_dict[key_] * self.label_dict[key_]["lam"]


        ##########单层 添加 GRL 分类器（用于 onehot_pattr 的属性对抗）
        # if hasattr(self, "grl_classifier"):
        #     domain_logits = self.grl_classifier(embedding)
        #     domain_loss = self.grl_loss_fn(domain_logits, labels_mixup["onehot_pattr"])
        #     loss_dict["domain_adv"] = domain_loss
        #     loss_dict["main"] += self.grl_lambda * domain_loss

        #################多层 === 每个分支加入 GRL 对抗属性分类 ===
        # if hasattr(self, "grl_classifiers"):
        #     for i, (z, grl_clf) in enumerate(zip(z_list, self.grl_classifiers)):
        #         domain_loss = grl_clf(z, labels_mixup["onehot_pattr"])
        #         loss_dict[f"domain_adv_{i}"] = domain_loss
        #         loss_dict["main"] += self.grl_lambda * domain_loss

        self.log_loss(torch.tensor(len(wave)).float(), f"train/batch_size", 1)
        for tag_, val_ in loss_dict.items():
            self.log_loss(val_, f"train/{tag_}", len(wave))

        return loss_dict["main"]
