# #########原来是第一行，改为了第二行
from .targetkmeans import TargetKmeansCos, TargetKmeansEuclid
#
# from .targetkmeans import TargetGWRP