# Copyright 2024 Takuya Fujimura

import logging

import numpy as np
from sklearn.cluster import KMeans
import os
os.environ["OMP_NUM_THREADS"] = "4"
from .utils import get_embed_from_df
from scipy.special import softmax
from sklearn.mixture import GaussianMixture
from sklearn.neighbors import LocalOutlierFactor, NearestNeighbors
from scipy.stats import entropy
#############原来的代码
def get_embed_from_df(df):
    e_cols = [col for col in df.keys() if col[0] == "e" and int(col[1:]) >= 0]
    return df[e_cols].values


class TargetKmeans:
    def __init__(self, hp):
        self.hp = hp
        self.kmeans = KMeans(n_clusters=hp, random_state=0)

    def fit(self, train_df):
        is_target = train_df["is_target"].values
        embed = get_embed_from_df(train_df)
        self.kmeans.fit(embed[is_target == 0])
        self.means_ta = embed[is_target == 1]

        if sum(is_target) == 0:
            logging.warn("TargetKNN.fit: number of target data is 0.")
            return False
        return True

    def anomaly_score(self, test_df):
        pass


class TargetKmeansCos(TargetKmeans):
    def __init__(self, hp):
        super().__init__(hp)

    def anomaly_score(self, test_df):
        embed = get_embed_from_df(test_df)
        # compute cosine distances
        means_so = self.kmeans.cluster_centers_
        eval_cos = np.min(
            1 - np.dot(embed, self.means_ta.transpose()),
            axis=-1,
            keepdims=True,
        )
        eval_cos = np.minimum(
            eval_cos,
            np.min(
                1 - np.dot(embed, means_so.transpose()),
                axis=-1,
                keepdims=True,
            ),
        )
        return {"plain": eval_cos.squeeze(-1)}


class TargetKmeansEuclid(TargetKmeans):
    def __init__(self, hp):
        super().__init__(hp)

    def anomaly_score(self, test_df):
        embed = get_embed_from_df(test_df)
        # compute cosine distances
        means_so = self.kmeans.cluster_centers_
        anom_score_ta = np.zeros((len(self.means_ta), len(embed)))
        for i in range(len(self.means_ta)):
            anom_score_ta[i] = np.sqrt(np.sum((embed - self.means_ta[i]) ** 2, axis=-1))
        anom_score_ta = np.min(anom_score_ta, axis=0)
        anom_score_so = np.zeros((self.hp, len(embed)))
        for i in range(self.hp):
            anom_score_so[i] = np.sqrt(np.sum((embed - means_so[i]) ** 2, axis=-1))
        anom_score_so = np.min(anom_score_so, axis=0)
        return {"plain": np.minimum(anom_score_so, anom_score_ta)}







#################GWRP不使用hp，只用原始样本
# def get_embed_from_df(df):
#     """从 dataframe 提取以 e 开头的嵌入列"""
#     e_cols = [col for col in df.columns if col.startswith("e") and col[1:].isdigit()]
#     return df[e_cols].values
#
#
# class TargetGWRP:
#     """
#     用于 GWRP 重标定的目标域异常分数计算模块
#     根据 ICASSP 2025 "Keeping the Balance" 论文，使用源域样本 + 少量目标样本作为参考集
#     """
#     def __init__(self, r=0):
#         self.r = r  # 衰减因子 r ∈ (0, 1)，越小越强调排名靠前的距离
#
#     def fit(self, train_df):
#         is_target = train_df["is_target"].values
#         embed = get_embed_from_df(train_df)
#         self.source_embed = embed[is_target == 0]
#         self.target_embed = embed[is_target == 1]
#
#         if len(self.target_embed) == 0:
#             logging.warning("TargetGWRP.fit: number of target samples is 0.")
#             return False
#
#         return True
#
#     def anomaly_score(self, test_df):
#         test_embed = get_embed_from_df(test_df)
#         # 参考点 = 源域样本 + 少量目标样本
#         ref_embed = np.vstack([self.source_embed, self.target_embed])
#         scores = compute_gwrp_cosine_anomaly_scores(test_embed, ref_embed, r=self.r)
#         return {"plain": scores}
#
#
# def compute_gwrp_cosine_anomaly_scores(test_embed, ref_embed, r=0):
#     """
#     使用 GWRP（Global Weighted Rank Pooling）方法计算异常分数
#     参数：
#         - test_embed: (N, D) 测试样本嵌入
#         - ref_embed: (M, D) 源 + 目标域参考样本
#         - r: 衰减因子，越小越强调距离排名靠前的参考点
#     返回：
#         - scores: (N,) 每个测试样本的 GWRP 异常分数
#     """
#     # L2 归一化
#     test_embed_norm = test_embed / np.linalg.norm(test_embed, axis=1, keepdims=True)
#     ref_embed_norm = ref_embed / np.linalg.norm(ref_embed, axis=1, keepdims=True)
#
#     # 余弦距离 = 1 - 相似度（越小越接近）
#     cos_sim = np.dot(test_embed_norm, ref_embed_norm.T)  # (N, M)
#     Acos = 1.0 - cos_sim  # (N, M)
#
#     # 排序距离（升序）
#     sorted_dists = np.sort(Acos, axis=1)  # (N, M)
#
#     # GWRP 权重：r^0, r^1, ..., r^{M-1}
#     M = ref_embed.shape[0]
#     weights = np.power(r, np.arange(M)).astype(np.float32)
#     weights /= np.sum(weights)  # 归一化
#
#     # 计算加权异常分数（越大越异常）
#     scores = np.sum(sorted_dists * weights[np.newaxis, :], axis=1)  # (N,)
#
#     return scores



#################源域增加权重1.8目前效果更好  重加权（Re-weighting）”机制
# def get_embed_from_df(df):
#     """从 dataframe 提取以 e 开头的嵌入列"""
#     e_cols = [col for col in df.columns if col.startswith("e") and col[1:].isdigit()]
#     return df[e_cols].values
#
#
# class TargetGWRP:
#     """
#     基于 r=0 最近邻的异常分数计算 + 源域加权优先
#     """
#
#     def __init__(self, source_weight=1.4):
#         """
#         :param source_weight: 源域参考点的加权系数（目标域默认为1.0）
#         """
#         self.source_weight = source_weight
#
#     def fit(self, train_df):
#         is_target = train_df["is_target"].values
#         embed = get_embed_from_df(train_df)
#
#         self.source_embed = embed[is_target == 0]
#         self.target_embed = embed[is_target == 1]
#
#         if len(self.target_embed) == 0:
#             logging.warning("TargetGWRP.fit: number of target samples is 0.")
#             return False
#
#         return True
#
#     def anomaly_score(self, test_df):
#         test_embed = get_embed_from_df(test_df)
#
#         # 构建参考集（源域加权）
#         ref_embed = np.vstack([self.source_embed, self.target_embed])
#         ref_weights = np.concatenate([
#             np.full(len(self.source_embed), fill_value=self.source_weight),
#             np.ones(len(self.target_embed))
#         ])
#
#         scores = compute_weighted_1nn_scores(test_embed, ref_embed, ref_weights)
#         return {"plain": scores}
#
#
# def compute_weighted_1nn_scores(test_embed, ref_embed, ref_weights):
#     """
#     基于加权最近邻（r=0）计算异常分数，参考点乘以加权系数
#     """
#     # L2 归一化
#     test_embed_norm = test_embed / np.linalg.norm(test_embed, axis=1, keepdims=True)
#     ref_embed_norm = ref_embed / np.linalg.norm(ref_embed, axis=1, keepdims=True)
#
#     # 计算余弦距离
#     cos_sim = np.dot(test_embed_norm, ref_embed_norm.T)  # shape: (N_test, N_ref)
#     dists = 1.0 - cos_sim
#
#     # 加权距离（源域影响更强）
#     weighted_dists = dists * ref_weights[np.newaxis, :]  # shape: (N_test, N_ref)
#
#     # 最小加权距离作为异常分数
#     scores = np.min(weighted_dists, axis=1)
#
#     return scores


