# models/grl_classifier.py
import torch.nn as nn
from models.grl import grad_reverse
############以前错误的
# class GRLClassifier(nn.Module):
#     def __init__(self, in_dim, hidden_dim, num_classes, lambda_=1.0):
#         super().__init__()
#         self.lambda_ = lambda_
#         self.classifier = nn.Sequential(
#             nn.Linear(in_dim, hidden_dim),
#             nn.BatchNorm1d(hidden_dim),
#             nn.ReLU(),
#
#             nn.Linear(hidden_dim, hidden_dim),
#             nn.BatchNorm1d(hidden_dim),
#             nn.ReLU(),
#
#             nn.Linear(hidden_dim, num_classes)  # 第3层 Linear + 输出
#         )
#
#     def forward(self, x):
#         x = grad_reverse(x, self.lambda_)
#         return self.classifier(x)

class GRLClassifier(nn.Module):
    def __init__(self, in_dim, hidden_dim, lambda_=1):
        super().__init__()
        self.lambda_ = lambda_
        self.classifier = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),

            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),


            nn.Linear(hidden_dim, hidden_dim)
        )

    def forward(self, x):
        x = grad_reverse(x, self.lambda_)
        return self.classifier(x)